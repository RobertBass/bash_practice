# !/bin/bash
# Ejemplo de empaquetamiento de archivos
# Autor: Roberto Bravo


echo -e "PROGRAMA DE EMPAQUETAMIENTO DE ARCHIVOS"
tar -cvf bash-practice.tar *.sh
