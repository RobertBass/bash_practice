#!/bin/bash
# Programa para revisar declaracion de variables

opcion=0
nombre=Roberto

echo "Opcion: $opcion y Nombre: $nombre"

export nombre

./03_variables2.sh
