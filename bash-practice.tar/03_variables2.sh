# !/bin/bash
# Programa para revisar declaracion de variables

echo "Nombre pasado del script 02: $nombre"
