# !/bin/bash
# Programa para realizar algunas operaciones utilitarias en Postgres
echo "Hola mundo"
