# !/bin/bash
# Programa interactivo
# Autor: Roberto Bravo

read -p "Cual es tu nombre? " nombre
read -p "Cual es tu edad? " edad

echo "Listo, tu nombre es $nombre y tienes $edad anios"
