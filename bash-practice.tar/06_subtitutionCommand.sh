# !/bin/bash
# Programa para ejecutar comando dentro de un programa y almacenarlos en variables
# Autor: Roberto Bravo

ubicacionActual=`pwd`
infoKernel=$(uname -a)

echo "Ubicacion Actual: $ubicacionActual"
echo "Info Kernel: $infoKernel"

